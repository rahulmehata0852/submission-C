const { getAllPosts, addPosts, deletePost, updatePost } = require("../controllers/userController")

const router = require("express").Router()


router

    .get("/posts", getAllPosts)
    .post("/add-post", addPosts)
    .delete("/delete-post/:postId", deletePost)
    .put("/modify-post/:postId", updatePost)


module.exports = router